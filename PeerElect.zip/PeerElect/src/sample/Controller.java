package sample;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;

public class Controller {

    private final Main mainApp = new Main();
    public Button Candidate;
    public Button Status;
    public Button peoplevote;
    public Button Admin;
    public VBox body;
    public VBox form;

    @FXML
    public void openAdminPage() {
        mainApp.switchScene("admin.fxml");
    }

    @FXML
    public void openPeopleVotePage() {
        mainApp.switchScene("people_vote.fxml");
    }

    @FXML
    public void openStatusPage() {
        mainApp.switchScene("status.fxml");
    }

    @FXML
    public void openCandidatePage() {
        mainApp.switchScene("candidate.fxml");
    }

    @FXML
    public void openHomePage(){mainApp.switchScene("sample.fxml");}
}
