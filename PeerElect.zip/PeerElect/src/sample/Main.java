package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.Objects;

public class Main extends Application {

    private static Stage primaryStage;


    @Override
    public void start(Stage primaryStage) throws Exception {
        Main.primaryStage = primaryStage;  // Store the primary stage reference
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("sample.fxml")));
        Scene initialScene = new Scene(root, 1400, 700); // Adjusted size
        primaryStage.setTitle("Simple Layout");
        primaryStage.setScene(initialScene);
        primaryStage.show();
    }

    // Method to switch scenes
    public void switchScene(String fxmlFile) {
        try {
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource(fxmlFile)));
            Scene newScene = new Scene(root, 1400, 700); // Adjusted size
            primaryStage.setScene(newScene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Method to get the primary stage
    public static Stage getPrimaryStage() {
        return primaryStage;
    }

    public static void main(String[] args) {
        launch(args);
    }
}


